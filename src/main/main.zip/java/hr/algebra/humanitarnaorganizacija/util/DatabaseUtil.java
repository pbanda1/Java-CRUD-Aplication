package hr.algebra.humanitarnaorganizacija.util;

public final class DatabaseUtil {
    private static final String URL = "jdbc:h2:./HumanitarianDB";

    private DatabaseUtil() {
    }
}

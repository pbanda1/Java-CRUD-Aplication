module hr.algebra.humanitarnaorganizacija {
    requires javafx.controls;
    requires javafx.fxml;
    requires jdk.jdi;
    requires java.management;


    opens hr.algebra.humanitarnaorganizacija to javafx.fxml;
    exports hr.algebra.humanitarnaorganizacija;
}